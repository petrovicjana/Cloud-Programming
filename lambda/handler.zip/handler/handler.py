import json
import boto3
from datetime import datetime

# Initialize DynamoDB resource
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('ExponentiationResults')


def lambda_handler(event, context):
    try:
        # Extract base and exponent from the request body
        body = json.loads(event['body'])
        base = int(body['base'])
        exponent = int(body['exponent'])

        # Calculate the result of exponentiation
        result = base ** exponent

        # Store the result in DynamoDB
        table.put_item(Item={
            'id': f"{base}^{exponent}",
            'base': base,
            'exponent': exponent,
            'result': result,
            'timestamp': datetime.now().isoformat()
        })

        # Return the result to the frontend
        return {
            'statusCode': 200,
            'body': json.dumps({'result': result}),
            'headers': {
                'Access-Control-Allow-Origin': '*',  
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            }
        }
    except Exception as e:
        # Handle errors and return a response with CORS headers
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)}),
            'headers': {
                'Access-Control-Allow-Origin': '*',  
                'Access-Control-Allow-Methods': 'POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type'
            }
        }
